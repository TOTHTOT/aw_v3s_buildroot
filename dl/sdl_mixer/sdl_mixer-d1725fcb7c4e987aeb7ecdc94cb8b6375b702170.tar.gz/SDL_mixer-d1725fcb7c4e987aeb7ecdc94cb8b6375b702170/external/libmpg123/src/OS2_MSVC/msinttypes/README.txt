
msinttypes-r29 from:

http://msinttypes.googlecode.com/
http://code.google.com/p/msinttypes/

